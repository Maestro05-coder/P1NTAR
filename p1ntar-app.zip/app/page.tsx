"use client"

import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ProgressCircle } from "@/components/progress-circle"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Brain, MessageSquare, RotateCcw, Zap, TrendingUp, Target } from "lucide-react"

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Welcome back, Adam!</h1>
          <p className="text-muted-foreground">Ready to continue your learning journey?</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Stats and Progress */}
          <div className="lg:col-span-2 space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2">
                    <Zap className="w-5 h-5 text-primary" />
                    <span className="text-sm font-medium text-muted-foreground">Total XP</span>
                  </div>
                  <p className="text-2xl font-bold text-foreground mt-2">2,450</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2">
                    <TrendingUp className="w-5 h-5 text-primary" />
                    <span className="text-sm font-medium text-muted-foreground">Current Level</span>
                  </div>
                  <p className="text-2xl font-bold text-foreground mt-2">8</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2">
                    <Target className="w-5 h-5 text-primary" />
                    <span className="text-sm font-medium text-muted-foreground">Study Streak</span>
                  </div>
                  <p className="text-2xl font-bold text-foreground mt-2">12 days</p>
                </CardContent>
              </Card>
            </div>

            {/* AI Study Modes */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Brain className="w-5 h-5 text-primary" />
                  <span>AI Study Modes</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2 bg-transparent">
                    <BookOpen className="w-6 h-6 text-primary" />
                    <span className="text-sm">Summarize</span>
                  </Button>
                  <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2 bg-transparent">
                    <MessageSquare className="w-6 h-6 text-primary" />
                    <span className="text-sm">Explain Simply</span>
                  </Button>
                  <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2 bg-transparent">
                    <Brain className="w-6 h-6 text-primary" />
                    <span className="text-sm">Quiz Me</span>
                  </Button>
                  <Button variant="outline" className="h-auto p-4 flex flex-col items-center space-y-2 bg-transparent">
                    <RotateCcw className="w-6 h-6 text-primary" />
                    <span className="text-sm">Revise Last Week</span>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                      <div>
                        <p className="font-medium text-foreground">Physics - Quantum Mechanics</p>
                        <p className="text-sm text-muted-foreground">Completed 2 hours ago</p>
                      </div>
                    </div>
                    <Badge variant="secondary">92%</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                      <div>
                        <p className="font-medium text-foreground">Chemistry - Organic Compounds</p>
                        <p className="text-sm text-muted-foreground">Completed 5 hours ago</p>
                      </div>
                    </div>
                    <Badge variant="secondary">87%</Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-primary rounded-full"></div>
                      <div>
                        <p className="font-medium text-foreground">Mathematics - Calculus</p>
                        <p className="text-sm text-muted-foreground">Completed yesterday</p>
                      </div>
                    </div>
                    <Badge variant="secondary">95%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Weekly Goal and Recommendations */}
          <div className="space-y-6">
            {/* Weekly Goal */}
            <Card>
              <CardHeader>
                <CardTitle>Weekly Goal</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col items-center">
                <ProgressCircle percentage={68} size={120}>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-foreground">68%</p>
                    <p className="text-xs text-muted-foreground">Complete</p>
                  </div>
                </ProgressCircle>
                <p className="text-sm text-muted-foreground mt-4 text-center">13.6 / 20 hours completed this week</p>
              </CardContent>
            </Card>

            {/* Smart Recommendations */}
            <Card>
              <CardHeader>
                <CardTitle>Smart Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-medium text-foreground text-sm">Review Physics Notes</p>
                      <Badge variant="destructive" className="text-xs">
                        Due Today
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">Based on your quiz performance</p>
                  </div>

                  <div className="p-3 bg-muted rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-medium text-foreground text-sm">Practice Chemistry Problems</p>
                      <Badge variant="secondary" className="text-xs">
                        Recommended
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">Strengthen weak areas</p>
                  </div>

                  <div className="p-3 bg-muted rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-medium text-foreground text-sm">Math Quiz: Derivatives</p>
                      <Badge variant="outline" className="text-xs">
                        Optional
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground">Test your understanding</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
