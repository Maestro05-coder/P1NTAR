"use client"

import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Trophy, Target, Flame, Star, Award, Crown, Zap } from "lucide-react"

export default function Achievements() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Achievements & Rewards</h1>
          <p className="text-muted-foreground">Track your progress and unlock new achievements</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Level Progress and Streaks */}
          <div className="lg:col-span-2 space-y-6">
            {/* Level Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Crown className="w-5 h-5 text-primary" />
                  <span>Level Progress</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-medium text-foreground">Level 8</span>
                    <span className="text-sm text-muted-foreground">2,450 / 3,000 XP</span>
                  </div>
                  <Progress value={81.7} className="h-3" />
                  <p className="text-sm text-muted-foreground">550 XP needed for Level 9</p>
                </div>
              </CardContent>
            </Card>

            {/* Study Streaks */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Flame className="w-5 h-5 text-primary" />
                  <span>Study Streaks</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-muted-foreground">Current Streak</span>
                        <span className="text-lg font-bold text-foreground">12 days</span>
                      </div>
                      <Progress value={60} className="h-2" />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-muted-foreground">Best Streak</span>
                        <span className="text-lg font-bold text-foreground">28 days</span>
                      </div>
                      <Progress value={100} className="h-2" />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-muted-foreground">This Month</span>
                        <span className="text-lg font-bold text-foreground">18 days</span>
                      </div>
                      <Progress value={75} className="h-2" />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-muted-foreground">All Time</span>
                        <span className="text-lg font-bold text-foreground">156 days</span>
                      </div>
                      <Progress value={85} className="h-2" />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Current Goals */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="w-5 h-5 text-primary" />
                  <span>Current Goals</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-foreground">Complete 20 hours this week</span>
                      <span className="text-sm text-muted-foreground">13.6 / 20 hours</span>
                    </div>
                    <Progress value={68} className="h-2" />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-foreground">Master Physics Chapter 12</span>
                      <span className="text-sm text-muted-foreground">7 / 10 topics</span>
                    </div>
                    <Progress value={70} className="h-2" />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-foreground">Achieve 90% quiz average</span>
                      <span className="text-sm text-muted-foreground">87% current</span>
                    </div>
                    <Progress value={87} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Unlocked Badges */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Trophy className="w-5 h-5 text-primary" />
                  <span>Unlocked Badges</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Epic Badges */}
                  <div>
                    <div className="flex items-center space-x-2 mb-3">
                      <Crown className="w-4 h-4 text-yellow-500" />
                      <span className="font-medium text-foreground">Epic</span>
                      <Badge variant="secondary" className="text-xs">
                        2
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex flex-col items-center p-3 bg-muted rounded-lg">
                        <Crown className="w-8 h-8 text-yellow-500 mb-2" />
                        <span className="text-xs text-center font-medium">Study Master</span>
                      </div>
                      <div className="flex flex-col items-center p-3 bg-muted rounded-lg">
                        <Flame className="w-8 h-8 text-orange-500 mb-2" />
                        <span className="text-xs text-center font-medium">Streak Legend</span>
                      </div>
                    </div>
                  </div>

                  {/* Rare Badges */}
                  <div>
                    <div className="flex items-center space-x-2 mb-3">
                      <Star className="w-4 h-4 text-purple-500" />
                      <span className="font-medium text-foreground">Rare</span>
                      <Badge variant="secondary" className="text-xs">
                        5
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex flex-col items-center p-3 bg-muted rounded-lg">
                        <Zap className="w-8 h-8 text-blue-500 mb-2" />
                        <span className="text-xs text-center font-medium">Quick Learner</span>
                      </div>
                      <div className="flex flex-col items-center p-3 bg-muted rounded-lg">
                        <Target className="w-8 h-8 text-green-500 mb-2" />
                        <span className="text-xs text-center font-medium">Goal Crusher</span>
                      </div>
                      <div className="flex flex-col items-center p-3 bg-muted rounded-lg">
                        <Award className="w-8 h-8 text-red-500 mb-2" />
                        <span className="text-xs text-center font-medium">Perfect Score</span>
                      </div>
                      <div className="flex flex-col items-center p-3 bg-muted rounded-lg">
                        <Trophy className="w-8 h-8 text-primary mb-2" />
                        <span className="text-xs text-center font-medium">Champion</span>
                      </div>
                    </div>
                  </div>

                  {/* Common Badges */}
                  <div>
                    <div className="flex items-center space-x-2 mb-3">
                      <Award className="w-4 h-4 text-gray-500" />
                      <span className="font-medium text-foreground">Common</span>
                      <Badge variant="secondary" className="text-xs">
                        8
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex flex-col items-center p-3 bg-muted rounded-lg">
                        <Trophy className="w-8 h-8 text-gray-500 mb-2" />
                        <span className="text-xs text-center font-medium">First Steps</span>
                      </div>
                      <div className="flex flex-col items-center p-3 bg-muted rounded-lg">
                        <Star className="w-8 h-8 text-gray-500 mb-2" />
                        <span className="text-xs text-center font-medium">Dedicated</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
