"use client"

import { Navigation } from "@/components/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { FileText, ImageIcon, Mic, Search, BookOpen } from "lucide-react"

export default function StudyLibrary() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Study Library</h1>
          <p className="text-muted-foreground">Upload and manage your learning materials</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Quick Upload */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Quick Upload</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full h-16 flex flex-col items-center space-y-2 bg-transparent" variant="outline">
                  <FileText className="w-6 h-6 text-primary" />
                  <span className="text-sm">Upload PDF</span>
                </Button>

                <Button className="w-full h-16 flex flex-col items-center space-y-2 bg-transparent" variant="outline">
                  <ImageIcon className="w-6 h-6 text-primary" />
                  <span className="text-sm">Upload Images</span>
                </Button>

                <Button className="w-full h-16 flex flex-col items-center space-y-2 bg-transparent" variant="outline">
                  <Mic className="w-6 h-6 text-primary" />
                  <span className="text-sm">Voice to Text</span>
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Right Column - Library Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input placeholder="Search your library..." className="pl-10" />
            </div>

            {/* Recent Uploads */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Uploads</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
                    <FileText className="w-8 h-8 text-primary" />
                    <div className="flex-1">
                      <p className="font-medium text-foreground">Physics_Chapter_12.pdf</p>
                      <p className="text-sm text-muted-foreground">Uploaded 2 hours ago • 2.4 MB</p>
                    </div>
                    <Button size="sm" variant="ghost">
                      <BookOpen className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
                    <ImageIcon className="w-8 h-8 text-primary" />
                    <div className="flex-1">
                      <p className="font-medium text-foreground">Chemistry_Notes_Scan.jpg</p>
                      <p className="text-sm text-muted-foreground">Uploaded 5 hours ago • 1.8 MB</p>
                    </div>
                    <Button size="sm" variant="ghost">
                      <BookOpen className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="flex items-center space-x-3 p-3 bg-muted rounded-lg">
                    <FileText className="w-8 h-8 text-primary" />
                    <div className="flex-1">
                      <p className="font-medium text-foreground">Math_Formulas.pdf</p>
                      <p className="text-sm text-muted-foreground">Uploaded yesterday • 3.1 MB</p>
                    </div>
                    <Button size="sm" variant="ghost">
                      <BookOpen className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Study Materials by Subject */}
            <Card>
              <CardHeader>
                <CardTitle>Study Materials by Subject</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium text-foreground">Physics</h3>
                      <span className="text-sm text-muted-foreground">12 files</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">Quantum mechanics, thermodynamics</p>
                    <Button size="sm" variant="outline" className="w-full bg-transparent">
                      View All
                    </Button>
                  </div>

                  <div className="p-4 bg-muted rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium text-foreground">Chemistry</h3>
                      <span className="text-sm text-muted-foreground">8 files</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">Organic compounds, reactions</p>
                    <Button size="sm" variant="outline" className="w-full bg-transparent">
                      View All
                    </Button>
                  </div>

                  <div className="p-4 bg-muted rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium text-foreground">Mathematics</h3>
                      <span className="text-sm text-muted-foreground">15 files</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">Calculus, algebra, geometry</p>
                    <Button size="sm" variant="outline" className="w-full bg-transparent">
                      View All
                    </Button>
                  </div>

                  <div className="p-4 bg-muted rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-medium text-foreground">Biology</h3>
                      <span className="text-sm text-muted-foreground">6 files</span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">Cell biology, genetics</p>
                    <Button size="sm" variant="outline" className="w-full bg-transparent">
                      View All
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
